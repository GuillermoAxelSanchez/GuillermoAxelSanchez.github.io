
export { crearCartaHTML } from './crear-carta-html';
export { crearDeck } from './crear-deck';
export { pedirCarta } from './pedir-carta';
export { turnoComputadora } from './turno-computadora';
export { valorCarta } from './valor-carta';